module.exports=[67118,(a,b,c)=>{}];

//# sourceMappingURL=65e5f_apps_realestate__next-internal_server_app_listings_create_page_actions_1818fbae.js.map