module.exports=[58255,(a,b,c)=>{}];

//# sourceMappingURL=65e5f_apps_realestate__next-internal_server_app_register_page_actions_23421677.js.map