module.exports=[55961,(a,b,c)=>{}];

//# sourceMappingURL=65e5f_apps_realestate__next-internal_server_app__not-found_page_actions_a050ddc9.js.map