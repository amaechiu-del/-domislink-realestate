module.exports=[15446,(a,b,c)=>{}];

//# sourceMappingURL=65e5f_apps_realestate__next-internal_server_app_page_actions_24206849.js.map