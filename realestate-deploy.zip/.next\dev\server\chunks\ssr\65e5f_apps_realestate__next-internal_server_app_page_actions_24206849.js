module.exports = [
"[project]/Desktop/domislink-empire_1/domislink-empire/apps/realestate/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=65e5f_apps_realestate__next-internal_server_app_page_actions_24206849.js.map