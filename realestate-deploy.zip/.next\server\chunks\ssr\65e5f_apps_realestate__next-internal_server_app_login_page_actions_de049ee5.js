module.exports=[36758,(a,b,c)=>{}];

//# sourceMappingURL=65e5f_apps_realestate__next-internal_server_app_login_page_actions_de049ee5.js.map