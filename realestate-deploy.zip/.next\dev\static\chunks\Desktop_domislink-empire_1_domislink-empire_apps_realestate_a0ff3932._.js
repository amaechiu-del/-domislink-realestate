(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_cde6c979._.js",
  "static/chunks/0b37b_next_dist_compiled_react-dom_667b64a2._.js",
  "static/chunks/0b37b_next_dist_compiled_react-server-dom-turbopack_a3400edc._.js",
  "static/chunks/0b37b_next_dist_compiled_next-devtools_index_462a5f45.js",
  "static/chunks/0b37b_next_dist_compiled_5164cdbd._.js",
  "static/chunks/0b37b_next_dist_client_8d49ec3e._.js",
  "static/chunks/0b37b_next_dist_33f337e0._.js",
  "static/chunks/0b37b_@swc_helpers_cjs_72a5b78e._.js"
],
    source: "entry"
});
