module.exports = [
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/Desktop/domislink-empire_1/domislink-empire/apps/realestate/src/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/domislink-empire_1/domislink-empire/apps/realestate/src/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/Desktop/domislink-empire_1/domislink-empire/apps/realestate/src/app/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$domislink$2d$empire_1$2f$domislink$2d$empire$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function Home() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$domislink$2d$empire_1$2f$domislink$2d$empire$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            background: "#0a0a0f",
            color: "white",
            minHeight: "100vh",
            padding: "50px",
            textAlign: "center"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$domislink$2d$empire_1$2f$domislink$2d$empire$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                style: {
                    color: "#EEFF00",
                    fontSize: "3rem"
                },
                children: "DomisLink Real Estate"
            }, void 0, false, {
                fileName: "[project]/Desktop/domislink-empire_1/domislink-empire/apps/realestate/src/app/page.tsx",
                lineNumber: 2,
                columnNumber: 112
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$domislink$2d$empire_1$2f$domislink$2d$empire$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "It works!"
            }, void 0, false, {
                fileName: "[project]/Desktop/domislink-empire_1/domislink-empire/apps/realestate/src/app/page.tsx",
                lineNumber: 2,
                columnNumber: 184
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/domislink-empire_1/domislink-empire/apps/realestate/src/app/page.tsx",
        lineNumber: 2,
        columnNumber: 10
    }, this);
}
}),
"[project]/Desktop/domislink-empire_1/domislink-empire/apps/realestate/src/app/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/domislink-empire_1/domislink-empire/apps/realestate/src/app/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__84b2c521._.js.map