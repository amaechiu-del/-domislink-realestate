module.exports=[70221,(a,b,c)=>{}];

//# sourceMappingURL=65e5f_apps_realestate__next-internal_server_app__global-error_page_actions_7ab6a0cd.js.map