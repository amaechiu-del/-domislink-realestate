module.exports=[78968,a=>{"use strict";var b=a.i(84979);function c({children:a}){return(0,b.jsx)("html",{children:(0,b.jsx)("body",{children:a})})}a.s(["default",()=>c])}];

//# sourceMappingURL=3d860_domislink-empire_1_domislink-empire_apps_realestate_src_app_layout_tsx_ab2e25a1._.js.map