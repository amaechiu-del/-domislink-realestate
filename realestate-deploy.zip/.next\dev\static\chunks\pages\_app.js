__turbopack_load_page_chunks__("/_app", [
  "static/chunks/0b37b_next_dist_compiled_e3be01e2._.js",
  "static/chunks/0b37b_next_dist_shared_lib_abfce71b._.js",
  "static/chunks/0b37b_next_dist_client_4ad67f80._.js",
  "static/chunks/0b37b_next_dist_91b5cf3a._.js",
  "static/chunks/0b37b_next_app_043913ff.js",
  "static/chunks/[next]_entry_page-loader_ts_7fb28d23._.js",
  "static/chunks/0b37b_react-dom_bd49985b._.js",
  "static/chunks/0b37b_fe08a0ac._.js",
  "static/chunks/[root-of-the-server]__536abced._.js",
  "static/chunks/Desktop_domislink-empire_1_domislink-empire_apps_realestate_pages__app_2da965e7._.js",
  "static/chunks/88e7d_domislink-empire_1_domislink-empire_apps_realestate_pages__app_d406c1a1._.js"
])
