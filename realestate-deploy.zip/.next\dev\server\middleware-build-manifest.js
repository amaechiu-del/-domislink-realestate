globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0b37b_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_cde6c979._.js",
    "static/chunks/0b37b_next_dist_compiled_react-dom_667b64a2._.js",
    "static/chunks/0b37b_next_dist_compiled_react-server-dom-turbopack_a3400edc._.js",
    "static/chunks/0b37b_next_dist_compiled_next-devtools_index_462a5f45.js",
    "static/chunks/0b37b_next_dist_compiled_5164cdbd._.js",
    "static/chunks/0b37b_next_dist_client_8d49ec3e._.js",
    "static/chunks/0b37b_next_dist_33f337e0._.js",
    "static/chunks/0b37b_@swc_helpers_cjs_72a5b78e._.js",
    "static/chunks/Desktop_domislink-empire_1_domislink-empire_apps_realestate_a0ff3932._.js",
    "static/chunks/turbopack-Desktop_domislink-empire_1_domislink-empire_apps_realestate_ae8793db._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];