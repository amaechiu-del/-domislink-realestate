(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/0b37b_next_dist_compiled_e3be01e2._.js",
  "static/chunks/0b37b_next_dist_shared_lib_9458c404._.js",
  "static/chunks/0b37b_next_dist_client_4ad67f80._.js",
  "static/chunks/0b37b_next_dist_11282c5f._.js",
  "static/chunks/0b37b_next_error_66c1a670.js",
  "static/chunks/[next]_entry_page-loader_ts_01db3858._.js",
  "static/chunks/0b37b_react-dom_bd49985b._.js",
  "static/chunks/0b37b_fe08a0ac._.js",
  "static/chunks/[root-of-the-server]__d29c9919._.js"
],
    source: "entry"
});
