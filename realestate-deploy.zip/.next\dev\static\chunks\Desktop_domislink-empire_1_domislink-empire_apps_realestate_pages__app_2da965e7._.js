(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/0b37b_next_dist_compiled_e3be01e2._.js",
  "static/chunks/0b37b_next_dist_shared_lib_abfce71b._.js",
  "static/chunks/0b37b_next_dist_client_4ad67f80._.js",
  "static/chunks/0b37b_next_dist_91b5cf3a._.js",
  "static/chunks/0b37b_next_app_043913ff.js",
  "static/chunks/[next]_entry_page-loader_ts_7fb28d23._.js",
  "static/chunks/0b37b_react-dom_bd49985b._.js",
  "static/chunks/0b37b_fe08a0ac._.js",
  "static/chunks/[root-of-the-server]__536abced._.js"
],
    source: "entry"
});
