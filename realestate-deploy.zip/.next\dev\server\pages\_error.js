var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/0b37b_94d123b5._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/_6bb74400._.js")
R.c("server/chunks/ssr/[externals]__fa248b9f._.js")
R.c("server/chunks/ssr/0b37b_next_31983610._.js")
R.m("[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
