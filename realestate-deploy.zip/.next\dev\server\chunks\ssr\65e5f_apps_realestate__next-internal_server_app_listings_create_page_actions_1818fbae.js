module.exports = [
"[project]/Desktop/domislink-empire_1/domislink-empire/apps/realestate/.next-internal/server/app/listings/create/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=65e5f_apps_realestate__next-internal_server_app_listings_create_page_actions_1818fbae.js.map