var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/_6bb74400._.js")
R.c("server/chunks/ssr/[externals]__fa248b9f._.js")
R.m("[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/Desktop/domislink-empire_1/domislink-empire/node_modules/next/document.js [ssr] (ecmascript)").exports
